package com.example.sim;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

public class TitrationGraph extends View {
    public TitrationGraph(Context context, AttributeSet attrs) {
        super(context, attrs);
    }
}
